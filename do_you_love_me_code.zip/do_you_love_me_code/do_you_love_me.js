const questionContainer = document.querySelector(".question-container");
const resultContainer = document.querySelector(".result-container");
const gifResult = document.querySelector(".gif-result");
const heartLoader = document.querySelector(".cssload-main");
const yesBtn = document.querySelector(".js-yes-btn");
const noBtn = document.querySelector(".js-no-btn");
const heartsBg = document.querySelector(".hearts-bg");

/* ---------- "No" button runs away ---------- */
function moveNoBtn(e) {
  if (e && e.cancelable) e.preventDefault();

  // Switch to fixed positioning so it can roam the whole screen
  noBtn.classList.add("running");

  const padding = 12;
  const maxX = window.innerWidth - noBtn.offsetWidth - padding;
  const maxY = window.innerHeight - noBtn.offsetHeight - padding - 40; // keep above footer

  const newX = Math.max(padding, Math.floor(Math.random() * maxX));
  const newY = Math.max(padding, Math.floor(Math.random() * maxY));

  noBtn.style.left = `${newX}px`;
  noBtn.style.top = `${newY}px`;
}

noBtn.addEventListener("mouseover", moveNoBtn);
noBtn.addEventListener("touchstart", moveNoBtn, { passive: false }); // mobile
noBtn.addEventListener("focus", moveNoBtn); // keyboard users
noBtn.addEventListener("click", moveNoBtn); // safety net

/* ---------- "Yes" button ---------- */
yesBtn.addEventListener("click", () => {
  questionContainer.style.display = "none";
  noBtn.style.display = "none";
  heartLoader.style.display = "block";

  setTimeout(() => {
    heartLoader.style.display = "none";
    resultContainer.style.display = "block";

    const playPromise = gifResult.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {}); // ignore autoplay rejection
    }
    burstHearts();
  }, 3000);
});

/* ---------- Floating hearts background ---------- */
function spawnHeart(container, burst = false) {
  const heart = document.createElement("span");
  heart.className = burst ? "float-heart burst" : "float-heart";
  heart.textContent = "❤";
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${14 + Math.random() * 26}px`;
  heart.style.animationDuration = `${(burst ? 3 : 6) + Math.random() * 5}s`;
  container.appendChild(heart);
  heart.addEventListener("animationend", () => heart.remove());
}

setInterval(() => spawnHeart(heartsBg), 700);

function burstHearts() {
  for (let i = 0; i < 40; i++) {
    setTimeout(() => spawnHeart(heartsBg, true), i * 60);
  }
}
